#ifndef __DELAY_H
#define	__DELAY_H

#include "stm32f10x.h"

void Delay_Ms(u16 time);

void Delay_Us(u16 time);

#endif
