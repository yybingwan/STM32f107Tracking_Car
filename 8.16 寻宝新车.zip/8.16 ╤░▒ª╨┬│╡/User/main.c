#include "stm32f10x.h"
#include "motor.h"
#include "adc.h"       
#include "usart.h"
#include "gpio.h"
#include "sound.h"
#include "delay.h"
#include "seconds.h"
#include "sports.h"
#include "5110.h"
#include "compass.h"

#define turn_left                   go(-a,a);Delay_Ms(t);go(0,0);Delay_Ms(t1);while(getadc(4)<gd&&getadc(3)<gd){ go(-a,a);Delay_Ms(t);go(0,0);Delay_Ms(t1);}tt=seconds1;while(seconds1<tt+500){go(0,0);};           //��ת����ʱʱ��
#define turn_right                  go(a,-a);Delay_Ms(t);go(0,0);Delay_Ms(t1);while(getadc(4)<gd&&getadc(3)<gd){ go(a,-a);Delay_Ms(t);go(0,0);Delay_Ms(t1);}tt=seconds1;while(seconds1<tt+500){go(0,0);};           //��ת����ʱʱ��
#define turn_left_t                 angle=read_hmc5883l();while(read_hmc5883l()<angle+20){go(-a,a);}go(0,0);Delay_Ms(100);	
#define turn_right_t								angle=read_hmc5883l();while(read_hmc5883l()>angle-20){go(a,-a);}go(0,0);Delay_Ms(100);	

#define turn_back_t1                angle=read_hmc5883l();while(read_hmc5883l()<angle+135){go(-a,a);}go(0,0);Delay_Ms(100);     //��ͷ ����ʱʱ��  16V��ѹ��Ӧ
#define turn_back_t2                angle=read_hmc5883l();while(read_hmc5883l()>angle-140){go(a,-a);}go(0,0);Delay_Ms(100);
#define turn_back_t3                angle=read_hmc5883l();while(read_hmc5883l()>angle-145){go(a,-a);}go(0,0);Delay_Ms(100);
#define turn_back_t4                angle=read_hmc5883l();while(read_hmc5883l()<angle+140){go(-a,a);}go(0,0);Delay_Ms(100);


#define go_and_turnleft             while(getadc(7)<2500)go_f(0.55*v);turn_left delay_go(100,0.7*v);delay_go_f(300,0.7*v);          //ѭ����ǰ������ת
#define go_and_turnright            while(getadc(16)<gd)go_f(0.55*v);turn_right delay_go(100,0.7*v);delay_go_f(300,0.7*v);        //ѭ����ǰ������ת
#define go_and_turnleft_45          while(getadc(7)<gd)go_f(n);go(0,0);Delay_Ms(t1);turn_left_t;delay_go_f(500,n);//delay_go(300,n);delay_go_f(300,n);       //ѭ����ǰ������ת45��
#define go_and_turnright_45         while(getadc(16)<gd)go_f(n);go(0,0);Delay_Ms(t1);turn_right_t;//delay_go(100,n);//delay_go(300,n);delay_go_f(300,n); //ѭ����ǰ������ת45��

#define goback_and_turnleft         while(getadc(8)<700)go_b(-0.7*v);go(-a,a);Delay_Ms(480*t); delay_go(150,0.7*v);delay_go_f(300,0.7*v);       //ѭ���ߺ��˺���ת
#define goback_and_turnright        while(getadc(15)<700)go_b(-0.7*v);go(a,-a);Delay_Ms(480*t); delay_go(150,0.7*v);delay_go_f(300,0.7*v);     //ѭ���ߺ��˺���ת

#define go_cross_strait__PT1_PT2		while(getadc(7)<gd){go_f(n);}delay_go(50,0.5*n);

#define go_cross_strait__PT1_Qiao		while(getadc(7)<gd){go_f(n);}delay_go(200,0.5*n);
#define go_cross_strait__Qiao_PT2		while(getadc(7)<gd){go_f(n);}delay_go(200,0.5*n);


#define go_cross_strait__tj_PT4_1 		while(getadc(16)<gd){go_f(n);}delay_go(200,0.5*n);
#define go_cross_strait__tj_PT4_2 		while(getadc(16)<gd){go_f(n);}delay_go(200,0.5*n);

#define go_cross_strait__PT4_PT3_1	while(getadc(16)<gd){go_f(n);}delay_go(200,0.5*n);
#define go_cross_strait__PT4_PT3_2	while(getadc(7)<gd){go_f(n);}delay_go(200,0.5*n);

#define go_cross_strait__PT3_PT1_1		while(getadc(7)<gd){go_f(n);}delay_go(250,0.5*n);
#define go_cross_strait__PT3_PT1_2		while(getadc(7)<gd){go_f(n);}delay_go(150,0.5*n);go(0,0);Delay_Ms(100);
#define go_cross_strait__PT3_PT1_3		while(getadc(7)<gd){go_f(n);}go(0,0);Delay_Ms(100);//delay_go(50,0.5*n);

#define go_cross_strait             while(getadc(16)<gd||getadc(7)<gd){go_f(n);Delay_Ms(10);}delay_go(200,0.5*n);                           //ʶ�𵽲�·��ֱ��
#define hit                         while(GetPort(1)==1&&GetPort(11)==1)go_f(0.6*v);//ײ����     
#define slow_down1                  tt=seconds1;while(seconds1<tt+2600){go_f(vd);}//�������� 
#define slow_down2                  tt=seconds1;while(seconds1<tt+1000){go_f(vd);}//�������� 

#define bridge                      while(getadc(4)>700&&getadc(3)>700){go_f(n);Delay_Ms(50);}tt=seconds1;while(seconds1<tt+1000){go(vu,vu);}while(getadc(5)<gd&&getadc(4)<gd&&getadc(3)<gd&&getadc(2)<gd){go_fb(vq);}delay_go(100,vq);go(500,500);Delay_Ms(100);//while(QingXie1==1&&QingXie2==0){delay_go_fb(500,vu);}while(QingXie1==1&&QingXie2==1){delay_go_fb(500,vq);}while(QingXie1==0&&QingXie2==1){delay_go_fb(500,vd);}while(getadc(5)>gd||getadc(4)>gd||getadc(3)>gd||getadc(2)>gd){go(1000,1000);Delay_Ms(500);}
#define taijie											delay_go_f(2000,n);delay_go_f(500,1000);while(getadc(8)<gd){go_f(1500);}go(0,0);delay_go(100,-2000);



/////////////////////////��λ���뿪��/GPIOD////////////////
#define BMKG1    GetPort_BoMaKaiGuan(GPIO_Pin_1)
#define BMKG2    GetPort_BoMaKaiGuan(GPIO_Pin_2)
#define BMKG3    GetPort_BoMaKaiGuan(GPIO_Pin_3)
#define BMKG4    GetPort_BoMaKaiGuan(GPIO_Pin_4)
#define BMKG5    GetPort_BoMaKaiGuan(GPIO_Pin_5)
#define BMKG6    GetPort_BoMaKaiGuan(GPIO_Pin_6)
#define BMKG7    GetPort_BoMaKaiGuan(GPIO_Pin_7)
#define BMKG8    GetPort_BoMaKaiGuan(GPIO_Pin_0)
////////////////////////һ����б������/GPIOD////////////////
#define QingXie1    GetPort_BoMaKaiGuan(GPIO_Pin_8)   
#define QingXie2    GetPort_BoMaKaiGuan(GPIO_Pin_9)



////////////////////////������ഫ����/GPIOA////////////////
#define CeJuA    GetPort(GPIO_Pin_8)
#define CeJuL    GetPort(GPIO_Pin_11)
#define CeJuR    GetPort(GPIO_Pin_12)

////////////////////////������ײ������/GPIOA////////////////
#define PengZHuangL    GetPort(GPIO_Pin_13)
#define PengZHuangR    GetPort(GPIO_Pin_15)


int n=3200;     			   //�ذ�����
int v1=1200;    			   //��ƽ̨�ٶ�
int v2=2000;     			   //����Ѳ����ǰ��

int vt=1000;     			 //��ƽ̨�ٶ�  
int v=5000;           


int vu=6000;//��ƽ̨�ٶ�
int vd=1000;//��ƽ̨�ٶ�
int vq=1500;//����Ѳ����ǰ��
int vp=1500;//ƽ̨����
int vj=1000;//��·�ڼ���


int gd=2000; 					//��ɫ��ɫ�ֽ���
int gd1=1000; 				//��ɫ�Ҷ�ֵ��΢����1000
int gd2=700; 					//�������ɫ�Ҷ�ֵ�ֽ�ֵ������
int gd3=1500;  				//��ɫ�Ҷ�ֵ�ֽ�ֵ����ƽ̨��

int a=4500;     	 		//�̵ص�ͷ�����ٶ�  
int b=4000;  					//ƽ̨��ͷ�����ٶ�   
float t=100;    			//ת����ʱ
float t1=100;          //ת����ͣ��ʱ
float tt;
extern u32 sec;
extern u8 SaoMiao;			//openmvɨ����


int i;
int speed=10;

float angle;

int main(void)
{
	MOTOR_Init();	 
	SystemInit();	/* ����ϵͳʱ��Ϊ72M */  
  ADC1_Init(); /* ��ʼ��ADC1 */
	USART1_Config();/* ���ڽ���openmvɨ���� */
	NVIC_Configuration(); 
	GetPort_Init();               //������ײ���ִ������������ų�ʼ��
	GetPort_BoMaKaiGuan_Init();   //���뿪�����ų�ʼ��
	TIM5_Init();                  
	
	RCC_Configuration();
	I2C_GPIO_Config();
	Init_HMC5883L();
//    SetPort_Init(); 	//����LED�ƣ����ͳ�����
//	  test_sensor_lcd();		 //lcd���16·����������	
//  	test_sensor_usart();   //�������16·����������	
//    Motor_Test(n);         //������Գ���
//    Servo_Test();          //�������	
		
	    if( BMKG1 ==1&&BMKG2 ==0&&BMKG3 ==0&&BMKG4 ==0&&BMKG5 ==0&&BMKG6 ==0&&BMKG7==0&&BMKG8==0)
	{ while(1){
		arrive_pf_1(1);
		slow_down1;
		go(0,0);
		Delay_Ms(10000);
		arrive_pf(4);
		slow_down2;
		go(0,0);
		Delay_Ms(10000);
		arrive_pf(2);
		slow_down1;
		go(0,0);
		Delay_Ms(10000);
		arrive_pf(3);
		slow_down1;
		go(0,0);
		Delay_Ms(10000);}
  //	Motor_Test(n);																					//������Գ���
	} 	              											  
	
	else if(BMKG1 ==0&&BMKG2 ==1&&BMKG3 ==0&&BMKG4 ==0&&BMKG5 ==0&&BMKG6 ==0&&BMKG7==0&&BMKG8==0)
	{
		while(1){
		go_and_turnright_45;
		taijie;
		turn_left_t;
		delay_go(200,1000);
			go(0,0);
			Delay_Ms(2000);
		}
//	Servo_Test();
	}                 												//�������
	
	else if(BMKG1 ==0&&BMKG2 ==0&&BMKG3 ==1&&BMKG4 ==0&&BMKG5 ==0&&BMKG6 ==0&&BMKG7==0&&BMKG8==0)
	{test_sensor_lcd();}           												  //lcd���16·����������	
	
	else if(BMKG1 ==0&&BMKG2 ==0&&BMKG3 ==0&&BMKG4 ==1&&BMKG5 ==0&&BMKG6 ==0&&BMKG7==0&&BMKG8==0)
	{	while(1){go_f(n);}}																		//Ѱ����ǰ��   
	
	else if(BMKG1 ==0&&BMKG2 ==0&&BMKG3 ==0&&BMKG4 ==0&&BMKG5 ==1&&BMKG6 ==0&&BMKG7==0&&BMKG8==0)
	{
		Servo1();																							//�������¹���
		Delay_Ms(500);
		slow_down1; 				
		bridge; 
		go(0,0);
	}
	
	else if(BMKG1 ==0&&BMKG2 ==0&&BMKG3 ==0&&BMKG4 ==0&&BMKG5 ==0&&BMKG6 ==1&&BMKG7==0&&BMKG8==0)
	{
		arrive_pf(1);																					//��ƽ̨����    
	}																	
	else if(BMKG1 ==0&&BMKG2 ==0&&BMKG3 ==0&&BMKG4 ==0&&BMKG5 ==0&&BMKG6 ==0&&BMKG7==1&&BMKG8==0)
	{
		go_and_turnright_45;																	//ѭ����ǰ������ת45��	
	}	
	else if(BMKG1 ==1&&BMKG2 ==1&&BMKG3 ==0&&BMKG4 ==0&&BMKG5 ==0&&BMKG6 ==0&&BMKG7==0&&BMKG8==0)
	{															
		go_and_turnleft_45;																	//ѭ����ǰ������ת45��	
	}	
	else if(BMKG1 ==1&&BMKG2 ==1&&BMKG3 ==1&&BMKG4 ==0&&BMKG5 ==0&&BMKG6 ==0&&BMKG7==0&&BMKG8==0)
	{	
			go(n,n);
			Delay_Ms(1000);		
		angle=read_hmc5883l();															//�����ǿ���ת��
		while(read_hmc5883l()<angle+180)
			{
				go(-a,a);
			}
			go(0,0);
			Delay_Ms(100);
			go(n,n);
			Delay_Ms(1000);
			angle=read_hmc5883l();
		while(read_hmc5883l()>angle-180)
			{
				go(a,-a);
			}
		  go(0,0);
	}	
	else if(BMKG1 ==0&&BMKG2 ==0&&BMKG3 ==0&&BMKG4 ==0&&BMKG5 ==0&&BMKG6 ==0&&BMKG7==0&&BMKG8==1)
	{
		
///////////////////////////��������������ѭ��///////////////////////////////////////
//		while(1)
//		{
//		if(SaoMiao=='3')
//		{
//		go(-n,n);
//		Delay_Ms(1000);
//		}
//	else if(SaoMiao=='4')
//		{
//		go(n,-n);
//		Delay_Ms(1000);
//		}
//	}
////////////////////// ////��һ��Ѱ��//////////////////////////////////////
	while(CeJuA==1){}
	while(CeJuA==0){Delay_Ms(1000);Servo1();break;}
  while(CeJuA==0){Delay_Ms(1000);}
	SaoMiao='a';
	
  	slow_down1; 	
		bridge; 
		go_cross_strait__Qiao_PT2;
		arrive_pf(2);		
		slow_down2;	
if(SaoMiao=='4')
	{
		go_and_turnright_45;
		taijie;
		turn_left_t;
		delay_go(200,1000);
		go_cross_strait__tj_PT4_1;
		go_cross_strait__tj_PT4_2;
		arrive_pf(4);
		Servo4();
		slow_down2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		arrive_pf(3);
		slow_down2;
		go_cross_strait__PT3_PT1_1;
		go_cross_strait__PT3_PT1_2;
		turn_left_t;
		delay_go(200,2000);
		delay_go_f(3000,2500);
		go_and_turnright_45;       
		arrive_pf_1(1);
		go(0,0);
	}
		
else if(SaoMiao=='3')
	{
		go_and_turnright_45;
		taijie;
		turn_left_t;
		delay_go(200,1000);
		go_cross_strait__tj_PT4_1;
		go_cross_strait__tj_PT4_2;
		arrive_pf(4);
		slow_down2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		arrive_pf(3);
		Servo4();
		slow_down2;
		go_cross_strait__PT3_PT1_1;
		go_cross_strait__PT3_PT1_2;
		turn_left_t;
		delay_go(200,2000);
		delay_go_f(3000,2500);
		go_and_turnright_45;       
		arrive_pf_1(1);
		go(0,0);
}	

else if(SaoMiao!='3'&&SaoMiao!='4')
	{
		go_and_turnright_45;
		taijie;
		turn_left_t;
		delay_go(200,1000);
		go_cross_strait__tj_PT4_1;
		go_cross_strait__tj_PT4_2;
		arrive_pf(4);
		slow_down2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		arrive_pf(3);
		slow_down2;
		go_cross_strait__PT3_PT1_1;
		go_cross_strait__PT3_PT1_2;
		turn_left_t;
		delay_go(200,2000);
		delay_go_f(3000,2500);
		go_and_turnright_45;       
		arrive_pf_1(1);
		go(0,0);
}	

	////////////////////// ////�ڶ���Ѱ��//////////////////////////////////////
	while(CeJuA==1){}
	while(CeJuA==0){Delay_Ms(1000);Servo1();break;}
  while(CeJuA==0){Delay_Ms(1000);}
	SaoMiao='a';
	
  	slow_down1; 	
		bridge; 
		go_cross_strait__Qiao_PT2;
		arrive_pf(2);		
		slow_down2;	
if(SaoMiao=='4')
	{ 
		go_and_turnright_45;
		taijie;
		turn_left_t;
		delay_go(200,1000);
		go_cross_strait__tj_PT4_1;
		go_cross_strait__tj_PT4_2;
		arrive_pf(4);
		Servo4();
		slow_down2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		arrive_pf(3);
		slow_down2;
		go_cross_strait__PT3_PT1_1;
		go_cross_strait__PT3_PT1_2;
		turn_left_t;
		delay_go(200,2000);
		delay_go_f(3000,2500);
		go_and_turnright_45;       
		arrive_pf_1(1);
		go(0,0);
	}
		
else if(SaoMiao=='3')
	{
		go_and_turnright_45;
		taijie;
		turn_left_t;
		delay_go(200,1000);
		go_cross_strait__tj_PT4_1;
		go_cross_strait__tj_PT4_2;
		arrive_pf(4);
		slow_down2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		arrive_pf(3);
		Servo4();
		slow_down2;
		go_cross_strait__PT3_PT1_1;
		go_cross_strait__PT3_PT1_2;
		turn_left_t;
		delay_go(200,2000);
		delay_go_f(3000,2500);
		go_and_turnright_45;       
		arrive_pf_1(1);
		go(0,0);
}	

else if(SaoMiao!='3'&&SaoMiao!='4')
	{
		go_and_turnright_45;
		taijie;
		turn_left_t;
		delay_go(200,1000);
		go_cross_strait__tj_PT4_1;
		go_cross_strait__tj_PT4_2;
		arrive_pf(4);
		slow_down2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		go_cross_strait__PT4_PT3_1;
		go_cross_strait__PT4_PT3_2;
		arrive_pf(3);
		slow_down2;
		go_cross_strait__PT3_PT1_1;
		go_cross_strait__PT3_PT1_2;
		turn_left_t;
		delay_go(200,2000);
		delay_go_f(3000,2500);
		go_and_turnright_45;       
		arrive_pf_1(1);
		go(0,0);
		}	
	}
}
			
//		  Led();	// ���ͳ�������־
					
//	 slow_down1;  
				
//   bridge;             
//    
//   arrive_pf(1);      
    
//    go_and_turnright_45         
    
//    go_and_turnright_135      
    
//    go_cross_strait ;         
//    
//    arrive_pf(1);      
//    
//    go_cross_strait ;         
//    
//    go_cross_strait  ;       
//    
//    go_cross_strait ;         
//    
//    go_cross_strait ;        
//    
//    arrive_pf(1);      
//    
//    go_cross_strait  ;       
//    
//    go_cross_strait  ;       
    
//    go_and_turnright_135       
    
//    
//    delay_go_f(3,v);      
    
    
    
//    go_and_turnright_45_1       
    
//    arrive_pf1(2);     
    
    
//    go(0,0);
//    Delay_Ms(1000); 

//while(1)
//{
//				go(n,n);
//				Delay_Ms(100);
//}







void arrive_pf(int i)              //   ǰ��ʱ����ƽ̨����  ̽Ѱ������ڶ����ֱ�                       
	{		
		while(1)
			{  
				go_f(n);
				while(CeJuL==0)
        {
					go(500,1500);
					Delay_Ms(500);
					break;
				}
//				if(getadc(16)>gd){go(2000,2000);Delay_Ms(200);}
				if(PengZHuangL==0||PengZHuangR==0){break;}
				}  
    go(0,0);
			Delay_Ms(200);
		go(-n,-n);
			Delay_Ms(150);
	  go(0,0);
			Delay_Ms(1000);
		Servo2();           //����� 
			Delay_Ms(500);
		Servo3();           //���ұ�
			Delay_Ms(2000);
		if(i==1)
		{
		turn_back_t1;
		}
		else if(i==2)
		{
		turn_back_t2;
		}
		else if(i==3)
		{
		turn_back_t3;
		}
		else if(i==4)
		{
		turn_back_t4;
		}
	}

void arrive_pf_1(int i)              //   ǰ��ʱ����ƽ̨����  ̽Ѱ������ڶ����ֱ�                       
	{		
		while(1)
			{  
				go_f(n);
				if(getadc(8)>2000){/*delay_go(10,n);*/ break;}
			}  
		go(0,0);
			Delay_Ms(500);
		turn_back_t1;
	}


/*********************************************END OF FILE**********************/

