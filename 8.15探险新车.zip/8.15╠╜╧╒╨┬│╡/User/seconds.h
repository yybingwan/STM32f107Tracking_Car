#ifndef __SECONDS_H
#define	__SECONDS_H

#include "stm32f10x.h"


#define seconds1 sec     //����
#define seconds0 (sec=0)
void TIM5_Init(void);

void TIM5_IRQHandler(void);

#endif 
