#ifndef __GPIO_H
#define	__GPIO_H

#include "stm32f10x.h"




void GetPort_Init(void);
u8 GetPort(u16 port);

void GetPort_BoMaKaiGuan_Init(void);  
u8 GetPort_BoMaKaiGuan(u16 port);

void SetPort_Init(void) ;

void SetPort(u16 port,int val);

void Led(void);

#endif





























































