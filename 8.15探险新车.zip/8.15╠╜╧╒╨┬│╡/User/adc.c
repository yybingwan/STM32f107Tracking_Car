#include "adc.h"
#include "usart.h"
#include "delay.h"
#include "5110.h"
#include "gpio.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_dma.h"


#define ADC1_DR_Address    ((u32)0x4001244C)	

extern u16  After_filter[M]; 


#define  N   50              //ÿͨ����50��
#define  M   16              //Ϊ16��ͨ��

u16  AD_Value[N][M];     //�������ADCת�������Ҳ��DMA��Ŀ���ַ
u16  After_filter[M];    //���������ƽ��ֵ֮��Ľ��

/*���ò���ͨ���˿� ʹ��GPIOʱ��	  ����ADC����PA0�˿��ź�*/
 void ADC1_GPIO_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;    
	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
  
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;		//����Ϊģ������
	GPIO_Init(GPIOA, &GPIO_InitStructure);			  //x=GPIOx
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;		//����Ϊģ������
	GPIO_Init(GPIOB, &GPIO_InitStructure);			  //x=GPIOx
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;		//����Ϊģ������
	GPIO_Init(GPIOC, &GPIO_InitStructure);			  //x=GPIOx

}


/*����ADC1�Ĺ���ģʽΪMDAģʽ  */
 void ADC1_Mode_Config(void)
{
  DMA_InitTypeDef DMA_InitStructure;
  ADC_InitTypeDef ADC_InitStructure;	
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE); //ʹ��DMA1ʱ��
	/* DMA channel1 configuration */
  DMA_DeInit(DMA1_Channel1);  //ָ��DMAͨ��
  DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address;//����DMA�����ַ
  DMA_InitStructure.DMA_MemoryBaseAddr = (u32)&AD_Value;	//����DMA�ڴ��ַ��ADCת�����ֱ�ӷ���õ�ַ
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC; //����Ϊ����Ϊ���ݴ������Դ
  DMA_InitStructure.DMA_BufferSize = N*M;	//DMA����������Ϊ1��
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_Init(DMA1_Channel1, &DMA_InitStructure);
  
  /* Enable DMA channel1 */
  DMA_Cmd(DMA1_Channel1, ENABLE);  //ʹ��DMAͨ��

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);	//ʹ��ADC1ʱ��
     
  /* ADC1 configuration */
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent; //ʹ�ö���ģʽ
  ADC_InitStructure.ADC_ScanConvMode = ENABLE;//ɨ��ģʽ
  ADC_InitStructure.ADC_ContinuousConvMode = ENABLE; //����ת��ģʽ
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None; 
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;//ʹ�������Ҷ���
  ADC_InitStructure.ADC_NbrOfChannel = 16;  // ֻ��16��ת��ͨ��
  ADC_Init(ADC1, &ADC_InitStructure);

  /* ADC1 regular channel11 configuration */ 
	
  ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 2, ADC_SampleTime_55Cycles5); //ͨ��1��������55.5��ʱ������
  ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 3, ADC_SampleTime_55Cycles5); 
  ADC_RegularChannelConfig(ADC1, ADC_Channel_3, 4, ADC_SampleTime_55Cycles5); 
  ADC_RegularChannelConfig(ADC1, ADC_Channel_4, 5, ADC_SampleTime_55Cycles5); 
	ADC_RegularChannelConfig(ADC1, ADC_Channel_5, 6, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 7, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_7, 8, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_8, 9, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_9, 10, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_10,11, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_11,12, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_12,13, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_13,14, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_14,15, ADC_SampleTime_55Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_15,16, ADC_SampleTime_55Cycles5);

  /* Enable ADC1 DMA */
  ADC_DMACmd(ADC1, ENABLE);	 //ʹ��ADC��DMA
  
  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE); //ʹ��ADC1

  /* Enable ADC1 reset calibaration register */   
  ADC_ResetCalibration(ADC1);
  /* Check the end of ADC1 reset calibration register */
  while(ADC_GetResetCalibrationStatus(ADC1));

  /* Start ADC1 calibaration */
  ADC_StartCalibration(ADC1);
  /* Check the end of ADC1 calibration */
  while(ADC_GetCalibrationStatus(ADC1));
     
  /* Start ADC1 Software Conversion */ 
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);  //��ʼת��
}

/*��ʼ��ADC1 */
void ADC1_Init(void)
{
	ADC1_GPIO_Config();
	ADC1_Mode_Config();
}


/*��ƽ��ֵ����*/
void filter(void)
{
      u32  sum = 0;
		  u8   i= 0;
      u8   count;    
          for(i=0;i<16;i++)
      {	
         for (count=0;count<N;count++)

          {	
           sum += AD_Value[count][i];
          }

          After_filter[i]=sum/N;

          sum=0;
      }

}






//��ȡ�˿�1-16�Ҷȴ�������ֵ
u32 getadc(u8 i)
{
	filter();	
	return 3300000/4096*After_filter[i-1]/1000;
}



//���������ԣ�LCD����Ҷȴ������Ĳ���ֵ
void test_sensor_lcd(void)                                        
{                                      
	LCD_All_Init();
	Delay_Ms(2000);	
  while(1)
 {
	Display_S(0,0,getadc(1));
	Display_S(0,1,getadc(2));
	Display_S(0,2,getadc(3));
	Display_S(0,3,getadc(4));
	Display_S(0,4,getadc(5));
	Display_S(0,5,getadc(6));
	
	Display_S(28,0,getadc(7));
	Display_S(28,1,getadc(8));
	Display_S(28,2,getadc(9));
	Display_S(28,3,getadc(10));
	Display_S(28,4,getadc(11));
	Display_S(28,5,getadc(12));
	
	Display_S(56,0,getadc(13));
	Display_S(56,1,getadc(14));
	Display_S(56,2,getadc(15));
	Display_S(56,3,getadc(16));
	Display_S(56,4,GetPort(GPIO_Pin_8));
	Display_S(56,5,GetPort(GPIO_Pin_12));
  }  
}



//���������ԣ���������Ҷȴ������Ĳ���ֵ
void test_sensor_usart(void)
{
	while(1)
	{
		printf("adcx1: %d\r\n",getadc(1));
		Delay_Ms(100);
		printf("adcx2: %d\r\n",getadc(2));
		Delay_Ms(100);
		printf("adcx3: %d\r\n",getadc(3));
		Delay_Ms(100);
		printf("adcx4: %d\r\n",getadc(4));
		Delay_Ms(100);
		printf("adcx5: %d\r\n",getadc(5));
		Delay_Ms(100);
		printf("adcx6: %d\r\n",getadc(6));
		Delay_Ms(100);
		printf("adcx7: %d\r\n",getadc(7));
		Delay_Ms(100);
		printf("adcx8: %d\r\n",getadc(8));
		Delay_Ms(100);
		printf("adcx9: %d\r\n",getadc(9));
		Delay_Ms(100);
		printf("adcx10: %d\r\n",getadc(10));
		Delay_Ms(100);
		printf("adcx11: %d\r\n",getadc(11));
		Delay_Ms(100);
		printf("adcx12: %d\r\n",getadc(12));
		Delay_Ms(100);
		printf("adcx13: %d\r\n",getadc(13));
		Delay_Ms(100);
		printf("adcx14: %d\r\n",getadc(14));
		Delay_Ms(100);
		printf("adcx15: %d\r\n",getadc(15));
		Delay_Ms(100);
		printf("adcx16: %d\r\n",getadc(16));
		Delay_Ms(2000);
	}  
}



