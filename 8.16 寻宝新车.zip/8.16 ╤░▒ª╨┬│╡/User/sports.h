#ifndef __SPORTS_H
#define	__SPORTS_H

#include "stm32f10x.h"
#include "delay.h"

void go_f(int n);

void delay_go(float time,int n);

void delay_go_f(float time,int n);

void delay_go_fb(float time,int n);

void go_b(int n);

void go_fb(int n);

void go_fb2(int n);   //����������ƽ̨��

u16 arrive_door(void);

void arrive_pf(int n);

void arrive_pf_1(int n);

#endif
