
#ifndef    	__MOTOR_H
#define			__MOTOR_H

#include "stm32f10x.h"
/*********************************
  motor 1 : ENA -- PB6(PWM), IN1--PB2, IN2--PB5
  PWM : TIM4, channel 1
	motor 2 : ENA -- PB7(PWM), IN1--PB8, IN2--PB9
  PWM : TIM4, channel 2
*********************************/

//PWM -- TIM4 channel 1, PB6, control ENA
//PWM -- TIM4 channel 2, PB7, control ENA
//#define		PWM_SetRatio(x)		(TIM3->CCR1=(x))
//#define		PWM_SetRatio2(y)	(TIM3->CCR2=(y))
//#define		PWM_Start1()				TIM_CCxCmd(TIM3, TIM_Channel_1, TIM_CCx_Enable)
//#define		PWM_Start2()				TIM_CCxCmd(TIM3, TIM_Channel_2, TIM_CCx_Enable)
//#define		PWM_Stop1()				TIM_CCxCmd(TIM3, TIM_Channel_1, TIM_CCx_Disable)	
//#define		PWM_Stop2()				TIM_CCxCmd(TIM3, TIM_Channel_2, TIM_CCx_Disable)	

//���Ŷ��壺PB1-IN1, PB2-IN2
//���Ŷ��壺PB1-IN1, PB2-IN2


#define		MOTOR_Port				GPIOB
#define		MOTOR_Pin_IN1			GPIO_Pin_2
#define		MOTOR_Pin_IN2			GPIO_Pin_5
#define		MOTOR_Pin_IN3			GPIO_Pin_8
#define		MOTOR_Pin_IN4			GPIO_Pin_9

//motorA control macros
#define		MOTOR_Forward1()	GPIO_SetBits(MOTOR_Port, MOTOR_Pin_IN2); \
                            GPIO_ResetBits(MOTOR_Port, MOTOR_Pin_IN1)
														
#define		MOTOR_Backward1()	GPIO_SetBits(MOTOR_Port, MOTOR_Pin_IN1); \
                            GPIO_ResetBits(MOTOR_Port, MOTOR_Pin_IN2)
														
//motorB control macros														
#define		MOTOR_Forward2()	GPIO_SetBits(MOTOR_Port, MOTOR_Pin_IN4); \
                            GPIO_ResetBits(MOTOR_Port, MOTOR_Pin_IN3)
														

#define		MOTOR_Backward2()	GPIO_SetBits(MOTOR_Port, MOTOR_Pin_IN3); \
                            GPIO_ResetBits(MOTOR_Port, MOTOR_Pin_IN4)
														
														
														
#define		MOTOR_Start1()			PWM_Start1()			//start motor without changing moving direction														
#define		MOTOR_Stop1()			PWM_Stop1()
#define		MOTOR_Start2()			PWM_Start2()			//start motor without changing moving direction														
#define		MOTOR_Stop2()			PWM_Stop2()



//#define		MOTOR_SetSpeed(x)		PWM_SetRatio(x)  //  300<x<900
//#define		MOTOR_SetSpeed2(y)		PWM_SetRatio2(y)


static void PWM_Init(void);

void  MOTOR_Init(void);

void go(int l_speed,int r_speed);

void Motor_Test(int n);

void Servo_1(u16 speed,u16 angle);
void Servo1(void);

void Servo_2(u16 speed,u16 angle);
void Servo2(void);

void Servo_3(u16 speed,u16 angle);
//void Servo3(int speed);
void Servo3(void);

void Servo_4(u16 speed,u16 angle);
void Servo4(void);

//void Servo_4(u16 speed,u16 angle);
//void Servo4(int speed);

void Servo_Test(void);
	
#endif

