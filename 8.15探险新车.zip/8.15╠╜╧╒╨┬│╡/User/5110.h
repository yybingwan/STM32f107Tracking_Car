#include "stm32f10x.h"

//����IO��
#define SCLK_1         GPIO_SetBits(GPIOC, GPIO_Pin_12)
#define SCLK_0		     GPIO_ResetBits(GPIOC, GPIO_Pin_12)
#define SDIN_1         GPIO_SetBits(GPIOC, GPIO_Pin_11)
#define SDIN_0	   	   GPIO_ResetBits(GPIOC, GPIO_Pin_11)
#define LCD_DC_1	     GPIO_SetBits(GPIOB, GPIO_Pin_15)
#define LCD_DC_0	     GPIO_ResetBits(GPIOB, GPIO_Pin_15)
#define LCD_CE_1	     GPIO_SetBits(GPIOB, GPIO_Pin_14)
#define LCD_CE_0	     GPIO_ResetBits(GPIOB, GPIO_Pin_14)
#define LCD_RST_1	     GPIO_SetBits(GPIOB, GPIO_Pin_13)
#define LCD_RST_0	     GPIO_ResetBits(GPIOB, GPIO_Pin_13)

void LCD_init(void);

void LCD_clear(void);

void LCD_move_chinese_string(unsigned char X, unsigned char Y, unsigned char T); 

void LCD_write_english_string(unsigned char X,unsigned char Y,char *s);

void LCD_write_chinese_string(unsigned char X, unsigned char Y,
                   unsigned char ch_with,unsigned char num,
                   unsigned char line,unsigned char row);
									 
void chinese_string(unsigned char X, unsigned char Y, unsigned char T);    
									 
void LCD_write_char(unsigned char c);
									 
void LCD_draw_bmp_pixel(unsigned char X,unsigned char Y,unsigned char *map,
                  unsigned char Pix_x,unsigned char Pix_y);

void LCD_write_byte(unsigned char dat, unsigned char dc);

void LCD_write_shu(unsigned char x,unsigned char y,unsigned char z) ;

void LCD_set_XY(unsigned char X, unsigned char Y) ;

void lcd5110_GPIO_Configuration(void);	

void display(u8 list,u8 row,u32 value);

void Display_S(u8 list,u8 row,u16 value);

void LCD_All_Init(void);

void RCC_Configuration(void);
