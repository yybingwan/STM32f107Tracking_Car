
#include "motor.h"
#include "adc.h"
#include "sports.h"
#include "delay.h"
#include "gpio.h"
#include "seconds.h"

extern int n;
extern int gd;
extern int gd1;
extern int gd2;
extern int a;
extern int v;
extern int vt;
extern u32 sec;
extern u32 tt;

//ѭ����ǰ��
void go_f(int n)
{
		if(getadc(4)>gd||getadc(3)>gd) {
     if(getadc(13)>gd||getadc(12)>gd||getadc(11)>gd||getadc(10)>gd){go(n,n);}
     else if(getadc(14)>gd){go(0.5*n,n);}
     else if(getadc(9)>gd){go(n,0.5*n);}
     else{go(n,n);}
     }
  
  else if(getadc(5)>gd) {
     if(getadc(9)>gd){go(n,n);}
     else if(getadc(10)>gd){go(0.2*n,n);}
     else if(getadc(11)>gd||getadc(12)>gd){go(0.1*n,n);}
     else if(getadc(13)>gd||getadc(14)>gd){go(-n,n);}//
     else{go(0.1*n,n);}
     }
   
  else if(getadc(2)>gd) { 
     if(getadc(14)>gd){go(n,n);}
     else if(getadc(13)>gd){go(n,0.2*n);}
     else if(getadc(11)>gd||getadc(12)>gd){go(n,0.1*n);}
     else if(getadc(10)>gd||getadc(9)>gd){go(n,-n);}
     else{go(n,0.1*n);}
 }  
    
  else if(getadc(6)>gd) { 
     if(getadc(9)>gd){go(0.1*n,n);}
     else if(getadc(10)>gd){go(0.1*n,n);}
     else if(getadc(11)>gd||getadc(12)>gd){go(0,n);Delay_Ms(50);}
     else if(getadc(13)>gd||getadc(14)>gd){go(-n,n);Delay_Ms(50);}
     else{go(0,n);}
 }
  
  else if(getadc(1)>gd) { 
     if(getadc(14)>gd){go(n,0.1*n);}
     else if(getadc(13)>gd){go(n,0.1*n);}
     else if(getadc(11)>gd||getadc(12)>gd){go(n,0);Delay_Ms(50);}
     else if(getadc(10)>gd||getadc(9)>gd){go(n,-n);Delay_Ms(50);}
     else{go(n,0);}
 }
 else 
    go(n,n);

}

//ֱ����ʱ
void delay_go(float time,int n){                            
    go(n,n);
		Delay_Ms(time);
}

//ѭ������ʱ
void delay_go_f(float time,int n){   
		tt=seconds1;
    while(seconds1<tt+time)
    go_f(n);
}




///////////////////////////////////////////////////////////////////////////////
//ѭ���ߺ���
void go_b(int n){                                         
		if(getadc(12)>gd||getadc(11)>gd) {
     if(getadc(5)>gd||getadc(4)>gd||getadc(3)>gd||getadc(2)>gd){go(-n,-n);}
     else if(getadc(6)>gd){go(-n,-0.5*n);}
     else if(getadc(1)>gd){go(-0.5*n,-n);}
     else{go(-n,-n);}
     }
  
  
  
  else if(getadc(13)>gd) {
     if(getadc(1)>gd){go(-n,-n);}
     else if(getadc(2)>gd){go(-n,-0.5*n);}
     else if(getadc(3)>gd||getadc(4)>gd){go(-n,-0.1*n);}
     else if(getadc(5)>gd||getadc(6)>gd){go(-n,n);}
     else{go(-n,-0.5*n);}
     }
  
  
  
  else if(getadc(10)>gd) { 
     if(getadc(6)>gd){go(-n,-n);}
     else if(getadc(5)>gd){go(-0.5*n,-n);}
     else if(getadc(3)>gd||getadc(4)>gd){go(-0.1*n,-n);}
     else if(getadc(2)>gd||getadc(1)>gd){go(n,-n);}
     else{go(-0.2*n,-n);}
 }  
  
  
  
  else if(getadc(14)>gd) { 
     if(getadc(1)>gd){go(-n,-0.2*n);}
     else if(getadc(2)>gd){go(-n,-0.1*n);}
     else if(getadc(3)>gd||getadc(4)>gd){go(-n,0);}
     else if(getadc(5)>gd||getadc(6)>gd){go(-n,n);}
     else{go(-n,0);}
 }
  
  
  
  else if(getadc(9)>gd) { 
     if(getadc(6)>gd){go(-0.2*n,-n);}
     else if(getadc(5)>gd){go(-0.1*n,-n);}
     else if(getadc(3)>gd||getadc(4)>gd){go(0,-n);}
     else if(getadc(2)>gd||getadc(1)>gd){go(n,-n);}
     else{go(0,-n);}
 }
 else 
    go(-n,-n);
}







//ѭ����ǰ��
void go_fb(int n){                                           
    if(getadc(5)<600&&getadc(2)<500) {go(n,n);}
    else if (getadc(5)<850) {go(0.01*n,n);}    
    else if (getadc(2)<850) {go(n,0.01*n);}
    else go(n,n);
		}

//ѭ������ʱǰ��
void delay_go_fb(float time,int n){   
		tt=seconds1;
    while(seconds1<tt+time)
    go_fb(n);
}		
		

//�����ν�
void go_fb2(int n)
	{ 
		
		 tt=seconds1;
     while(seconds1<tt+300){
        if(getadc(16)>gd) {go(n,-n);}
        else if (getadc(7)>gd) {go(-n,n);}
        else if (getadc(1)>gd) {go(n,0.2*n);}
        else if (getadc(6)>gd) {go(0.2*n,n);}
        else if (getadc(2)>gd) {go(n,0.67*n);}
        else if (getadc(5)>gd) {go(0.67*n,n);}
        else {go(n,n);}
  }

}


////ǰ��ʱ������  ////////////////////////
u16 arrive_door(void)                                                   
{
    while(GetPort(GPIO_Pin_12)==1){go_f(0.6*v);}
    //wait(0.05);                        //��ǰ��һ�η�ֹ����������
    go(0,0);Delay_Ms(2000);              //����ǰ�����뿴���Ƿ�
    if(GetPort(GPIO_Pin_12)==0) return 0;          //��δ��
    else return 1;                                   //�ſ���
}











