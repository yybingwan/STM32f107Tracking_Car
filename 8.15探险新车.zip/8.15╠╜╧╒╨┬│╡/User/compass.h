#ifndef __COMPASS_H
#define	__COMPASS_H



void I2C_GPIO_Config(void);

void  Init_HMC5883L(void);
 
float read_hmc5883l(void);

#endif 


