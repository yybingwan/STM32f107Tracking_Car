#ifndef __ADC_H
#define	__ADC_H

#include "stm32f10x.h"


void ADC1_GPIO_Config(void);
void ADC1_Mode_Config(void);
void ADC1_Init(void);
void filter(void);
u32 getadc(u8 i);
void test_sensor_lcd(void);
void test_sensor_usart(void);
#define  N   50              //ÿͨ����50��
#define  M   16               //Ϊ16��ͨ��





#endif 


